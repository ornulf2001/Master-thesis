classdef MHEclass_KF_Update
    
    properties
        N_MHE             %Horizon length #timesteps
        nStates           %Number of states
        nControls         %Number of control inputs
        nMeasurements     %Number of measurements
        Ac                %Continuous time system matrix, A
        Bc                %Continuous time control matrix, B
        A                 %Discrete time system matrix, A
        B                 %Discrete time control matrix, B
        C                 %Measurement matrix, C
        Q                 %Weight matrix for process noise, w
        R                 %Weight matrix for measurement noise, v
        M                 %Weight matrix for arrival cost, x0 - xprior
        weightScaling     %Downscaling of Q, R, M matrices used in the filter to avoid ill posed hessian
        P                 %Parameters matrix. Stores xprior, measurements and control inputs
        G                 %QP cost matrix for quadratic terms
        g                 %QP cost vector for linear terms
        Aeq               %QP equality constraint matrix for z, Aeq*z=beq
        beq               %QP equality constraint vector for constant terms
        lb                %Decision variable constraints lb
        ub                % ---||--- ^ ub
        f                 %Nonlinear dynamical model, x_{k+1} = f(x_k, u_k) + w_k
        h                 %Nonlinear measurement model y_k = h(x_k, u_k) + v_k
        x0                %Initial condition for states
        xlp               %Linearization point for nonlinear model    
        xprior            %Prior for states (initial condition or previous state estimate)
        P0                %State covariance
        currentP            %Forward propegated state estimate covariance at k
        xCurrent          %Current state estimate, xk
        vCurrent          %Current measurement noise estimate
        wCurrent          %Current process noise estimate
        currentNIS        %Current NIS
        currentInnovation %Current innovation
        zOpt              %Solution to QP
        zPrev             %Previous solution to QP for warm start
        lastWsetB         %Previous working set - bounds - for warm start
        lastWsetC         %Previous working set - constraints - for warm start
        dt                %Sampling time for discretization of continuous time dynamics
        isReadyToRun      %Flag to start running MHE
        yBufferCount      %Counter for buffering of measurements in P
        uBufferCount      %Counter for buffering of control inputs in P
        options           %Quadprog solver options
        iterations        %Number of iterations run
        
        
    end
    
    methods
        function obj = MHEclass_KF_Update(N_MHE, Ac, Bc, C,Q,R,M,weightScaling, x0,xlp,P0, dt,options)
            
            %Assigning arguments to class properties
            obj.N_MHE = N_MHE;
            obj.Ac = Ac;
            obj.Bc = Bc;
            obj.Q=Q;
            obj.R=R;
            obj.M=M;
            obj.weightScaling = weightScaling;
            obj.C = C;
            obj.dt = dt;
            obj.xlp = xlp;
            obj.x0 = x0;
            obj.P0 = P0;
            obj.nStates= size(Ac,1);
            obj.nControls = size(Bc,2);
            obj.nMeasurements=size(C,1);
            obj.options= options;
            obj.iterations = 0;

           
            % running setup
            obj = obj.setup();
        end        
        
        function obj=setup(obj)
            
            % Discretizing dynamics and initializing P. 
            obj.A = expm(obj.Ac * obj.dt);
            obj.B = (obj.A - eye(size(obj.Ac))) * (obj.Ac \ obj.Bc);
            %obj.B = inv(obj.Ac) * (expm(obj.Ac * obj.dt) - eye(size(obj.Ac))) * obj.Bc;
            %obj.A=eye(size(obj.Ac))+obj.Ac*obj.dt;
            %obj.B=obj.Bc*obj.dt;

            obj.P = zeros(obj.nStates+obj.nMeasurements+obj.nControls, 1+(obj.N_MHE+1)+obj.N_MHE); 
            obj.P(1:obj.nStates,1)=obj.x0;
            obj.P(obj.nStates + 1:obj.nStates + obj.nMeasurements,2:obj.N_MHE+2)=(obj.C*obj.x0).*ones(obj.nMeasurements,obj.N_MHE+1);
            %obj.P(obj.nStates+1:obj.nStates+obj.nMeasurements, 2) = obj.C*obj.x0;
            obj.zPrev = [obj.x0;zeros(obj.N_MHE*obj.nStates,1);zeros(obj.N_MHE*obj.nStates,1);zeros((obj.N_MHE+1)*obj.nMeasurements,1)];

            nVars = length(obj.zPrev);          % Total number of decision variables
            nConstr = size(obj.Aeq, 1);         % Total number of general constraints

            % On first iteration only:
            obj.lastWsetB = zeros(nVars, 1);    % No bounds active initially
            obj.lastWsetC = zeros(nConstr, 1);  % No constraints active initially

            % Buffering init
            obj.isReadyToRun = false;
            obj.yBufferCount = 1;
            obj.uBufferCount = 1;
            
            
            %Setup optimization problem, G, g, Aeq, beq etc.
            obj = obj.setupOptimizationProblem(); 

        end
        
        function obj=setupOptimizationProblem(obj)
            
            % Constructing G
            cost_X_block = blkdiag(obj.weightScaling*obj.M,zeros(obj.nStates*obj.N_MHE)); %Arrival cost, for x0
            cost_Q_block = kron(eye(obj.N_MHE),obj.weightScaling*obj.Q); %Stage costs for process noise, w
            cost_R_block= kron(eye(obj.N_MHE+1),obj.weightScaling*obj.R); %stage costs for measurement noise, v
            obj.G=blkdiag(cost_X_block,cost_Q_block,cost_R_block);
            
            
            % Constructing g
            g_X=[-2*obj.weightScaling*obj.M*obj.P(1:obj.nStates,1);zeros(obj.nStates*obj.N_MHE,1)]; %Arrival cost. Only linear term is -2*M*xprior*x(0)
            g_W = zeros(obj.nStates * obj.N_MHE, 1);
            g_V = zeros(obj.nMeasurements * (obj.N_MHE + 1), 1);
            obj.g = [g_X; g_W; g_V];
            
            % Constructing Aeq and beq
            rows_Aeq= obj.N_MHE*obj.nStates+(obj.N_MHE+1)*obj.nMeasurements;
            cols_Aeq= (obj.N_MHE+1)*obj.nStates + obj.N_MHE*obj.nStates + (obj.N_MHE+1)*obj.nMeasurements;
            obj.Aeq =zeros(rows_Aeq,cols_Aeq);
            obj.beq = zeros(rows_Aeq, 1);
            
            for k = 0:obj.N_MHE-1
                obj.Aeq(obj.nStates*k+1 : obj.nStates*(k+1), obj.nStates*k+1 : obj.nStates*(k+1)) = -obj.A;
                obj.Aeq(obj.nStates*k+1 : obj.nStates*(k+1), obj.nStates*(k+1)+1 : obj.nStates*(k+2)) = eye(obj.nStates);
                obj.Aeq(obj.nStates*k+1 : obj.nStates*(k+1), obj.nStates*(obj.N_MHE+1) + obj.nStates*k + 1 :obj.nStates*(obj.N_MHE+1) + obj.nStates*(k+1)) = -eye(obj.nStates);
            end
            
            for k=0:obj.N_MHE
                obj.Aeq(obj.nStates*obj.N_MHE+obj.nMeasurements*k+1 : obj.nStates*obj.N_MHE+obj.nMeasurements*(k+1), obj.nStates*k+1 : obj.nStates*(k+1))=obj.C;
                obj.Aeq(obj.nStates*obj.N_MHE+obj.nMeasurements*k+1 : obj.nStates*obj.N_MHE+obj.nMeasurements*(k+1), obj.nStates*(obj.N_MHE+1)+obj.nStates*(obj.N_MHE)+obj.nMeasurements*k+1 : obj.nStates*(obj.N_MHE+1)+obj.nStates*(obj.N_MHE)+obj.nMeasurements*(k+1)) = eye(obj.nMeasurements);
            end
            obj.Aeq=sparse(obj.Aeq);
            obj.G=sparse(obj.G);

            % Bounds (from chat)
            nX = obj.nStates;
            N = obj.N_MHE;
            zDim = length(obj.zPrev);   % total number of decision variables
            lb = -inf(zDim, 1)         % default lower bound
            ub =  inf(zDim, 1);         % default upper bound
            z_min = 0.02;
            z_max = 0.1;
            
            for j = 0:N
                idx = j*nX + 3;  % index for z position in x_k
                lb(idx) = z_min;
                ub(idx) = z_max;
            end
            
            % Optional: limit zdot (index 8)
            zdot_min = -2;
            zdot_max = 2;
            for j = 0:N
                idx = j*nX + 8;
                lb(idx) = zdot_min;
                ub(idx) = zdot_max;
            end
            
            obj.lb = lb;
            obj.ub = ub;
        end
        
       
        
       
        
        function obj=runMHE(obj,newY,newU)
            obj.iterations = obj.iterations+1;
            

            % Row and column indices for control-block and measurement-block in P
            ctrl_start = obj.nStates + obj.nMeasurements + 1;
            ctrl_end   = ctrl_start + obj.nControls - 1;
            col_ctrl_start = 1 + (obj.N_MHE+1) + 1;
            col_ctrl_end   = 1 + (obj.N_MHE+1) + obj.N_MHE;
            meas_start = obj.nStates + 1;
            meas_end   = obj.nStates + obj.nMeasurements;
            col_meas_start = 2;
            col_meas_end = 1 + (obj.N_MHE+1);  % which equals N_MHE + 2

            if obj.N_MHE == 1
                % For a one-step horizon, just assign newU to the only control column.
                obj.P(ctrl_start:ctrl_end, col_ctrl_start) = newU;
            else
                % For N_MHE > 1, shift left by one column and insert the new control.
                obj.P(ctrl_start:ctrl_end, col_ctrl_start:col_ctrl_end) = ...
                    [ obj.P(ctrl_start:ctrl_end, col_ctrl_start+1:col_ctrl_end), newU ];
            end

            obj.P(meas_start:meas_end, col_meas_start:col_meas_end) = ...
                [ obj.P(meas_start:meas_end, col_meas_start+1:col_meas_end), newY ];

           
            %update the C*Xk + Vk = Ymeas,k constraint with new measurement in beq
            obj.beq(obj.nStates*obj.N_MHE+1 : obj.nStates*obj.N_MHE+obj.nMeasurements*(obj.N_MHE+1)) = reshape( obj.P(meas_start:meas_end, col_meas_start:col_meas_end), [], 1 );

            %Update dynamics constraint with new control input in beq
            obj.beq(1:obj.nStates*obj.N_MHE) = reshape(...
                obj.B * obj.P(ctrl_start:ctrl_end, col_ctrl_start:col_ctrl_end), ...
                    obj.nStates*obj.N_MHE, 1);


            obj = obj.computeNIS(); %Find current NIS
           
            %solve opt problem, currently only extracting zOpt
            [obj.zOpt, ~, exitflag, ~,~] = quadprog(2*obj.G, obj.g,[],[], obj.Aeq, obj.beq, [], [], obj.zPrev, obj.options);  
            %auxInput=qpOASES_auxInput('x0',obj.zPrev,...
            %                           'guessedWorkingSetB', obj.lastWsetB, ...
            %                           'guessedWorkingSetC', obj.lastWsetC);
            %[obj.zOpt, ~, exitflag, iter, ~,auxOutput] = qpOASES(2*obj.G, obj.g, obj.Aeq, [], [], obj.beq, obj.beq,obj.options,auxInput);
            %obj.lastWsetB = auxOutput.workingSetB;
            %obj.lastWsetC = auxOutput.workingSetC;

            %disp("exitflag: "+ string(exitflag)+", iter: "+ string(iter))
            
            obj.zPrev = obj.zOpt;
            x_zero = obj.zOpt(1:obj.nStates); %x0 estimate | MHE gives x^= [x0^,x1^,...xk^]

            % Extract the control input at the start of the horizon (k-N)
            u_kN = obj.P(obj.nStates+obj.nMeasurements+1:end, 1+(obj.N_MHE+1)+1); % Correct index for u_{k-N}
            
            % Predict x_zero (k-N) to k-N+1 using u_{k-N}
            x_predicted = obj.A * x_zero + obj.B * u_kN; 
            P_predicted = obj.A * obj.P0 * transpose(obj.A) + inv(obj.Q); % Q_MHE is inverse covariance
            
            % Extract measurement at k-N+1 
            y_k_Nplus1 = obj.P(obj.nStates+1:obj.nStates+obj.nMeasurements, 3); % Index 3 corresponds to k-N+1
            
            % Compute innovation using the correct measurement
            innovation = y_k_Nplus1 - obj.C * x_predicted;
            
            % Kalman gain and update
            S_cov_upd = obj.C * P_predicted * transpose(obj.C) + inv(obj.R);
            % Regularize S_cov_upd to avoid numerical issues
            S_reg = S_cov_upd+ 1e-6 * eye(size(S_cov_upd));
            kalman_gain = P_predicted * transpose(obj.C)/S_reg; % Use matrix division for stability
            
            x_corrected = x_predicted + kalman_gain * innovation;
            P_corrected = (eye(obj.nStates) - kalman_gain * obj.C) * P_predicted * transpose((eye(obj.nStates)-kalman_gain*obj.C)) + kalman_gain*inv(obj.R)*transpose(kalman_gain);
            
            % Regularize P_corrected before inverting
            P_reg = P_corrected+ 1e-6 * eye(obj.nStates);
            obj.P0 = P_reg; %Update arrival cost covariance initial guess
            newM = obj.weightScaling*inv(P_reg); %Calculate new arrival cost weight
          
            obj.xprior = obj.zOpt(obj.nStates + 1 : 2 * obj.nStates);  %Update xprior in arrival cost as x1^ from MHE
            %obj.xprior = x_corrected; %Could instead update xprior as the x_corrected (propagated KF style from x0^)
            obj.M=1/2*(newM+transpose(newM));


            obj.xCurrent=obj.zOpt(obj.nStates*obj.N_MHE + 1 : obj.nStates*(obj.N_MHE + 1)); %Extract current state estimate xk^
            obj.vCurrent=obj.zOpt(obj.nStates*(obj.N_MHE+1) + obj.nStates*obj.N_MHE+obj.nMeasurements*obj.N_MHE+1: obj.nStates*(obj.N_MHE+1) + obj.nStates*obj.N_MHE+obj.nMeasurements*(obj.N_MHE+1));
            obj.wCurrent=obj.zOpt(obj.nStates*(obj.N_MHE+1)+obj.nStates*obj.N_MHE+1:obj.nStates*(obj.N_MHE+1)+obj.nStates*(obj.N_MHE+1) );
            % Update arrival cost with new xprior
            obj.P(1:obj.nStates,1) = obj.xprior; 

            %Update G and g in cost function
            obj.g(1:obj.nStates) = -2*obj.M*obj.P(1:obj.nStates,1);
            obj.G(1:obj.nStates, 1:obj.nStates) = obj.M;

            

            
        end
        
        function obj = reset(obj, newx0) %% This is not in use
            
            %Reset initial condition, xCurrent and run setup again
            obj.x0 = newx0;           
            obj.xCurrent = [];
            obj = obj.setup();  % Reinitialize the matrices if necessary
        end

        function obj = computeNIS(obj) 
            
            %From chatGPT:
            % computeNIS Propagate the arrival cost from k-N to k and compute the NIS.
            % We assume:
            % - The arrival state is stored in obj.P(1:obj.nStates,1)
            % - The arrival covariance is stored in obj.P0
            % - The system matrices are obj.A, obj.B, obj.C.
            % - Process noise covariance is Q_cov = inv(obj.Q)
            % - Measurement noise covariance is R_cov = inv(obj.R)
            % - The horizon measurements are stored in columns 2:obj.N_MHE+2 of
            %   the measurement block: rows (obj.nStates+1:obj.nStates+obj.nMeasurements)
            % - The horizon controls are stored in columns (1+(obj.N_MHE+1)+1 : 1+(obj.N_MHE+1)+obj.N_MHE)
            %
            % The function propagates the state and covariance forward using a discrete-time
            % KF update for each horizon step and then computes the NIS based on the final innovation.
            
            % Define covariances from the weighting (as used in your runMHE)
            Q_cov = inv(obj.Q);  % process noise covariance (from your cost formulation)
            R_cov = inv(obj.R);  % measurement noise covariance
            
            % Initialize propagation with the arrival cost (prior) at time k-N+1.
            x_prop = obj.P(1:obj.nStates,1);  % Prior state estimate.
            P_prop = obj.P0;                  % Prior covariance.
            
            % Loop over the horizon steps (assume horizon length = N_MHE)
            for i = 1:obj.N_MHE
                % --- Prediction Step ---
                % Extract the control input at step i from the stored block.
                % We assume controls are stored in rows (nStates+nMeasurements+1:end) in column:
                colU = 1 + (obj.N_MHE+1) + i;
                u_i = obj.P(obj.nStates+obj.nMeasurements+1 : obj.nStates+obj.nMeasurements+obj.nControls, colU);
                
                % Predict state and covariance using the linear model.
                x_pred = obj.A * x_prop + obj.B * u_i;
                P_pred = obj.A * P_prop * obj.A' + Q_cov;
                
                % --- Measurement Update ---
                % Extract the measurement for next time step (i+2, since column 1 is for the arrival state and column 2 is the measurement corresponding to the arrival state)
                colY = 1+i+1 ;
                y_i = obj.P(obj.nStates+1 : obj.nStates+obj.nMeasurements, colY);
                
                % Compute innovation: the difference between the stored measurement and prediction.
                innovation = y_i - obj.C * x_pred;
                
                % Compute the innovation covariance.
                S = obj.C * P_pred * obj.C' + R_cov;
                
                % Compute the Kalman gain.
                K = P_pred * obj.C' / S;
                
                % Update the state and covariance.
                x_upd = x_pred + K * innovation;
                % For covariance, using the Joseph form for improved numerical consistency.
                I = eye(obj.nStates);
                P_upd = (I - K * obj.C) * P_pred * (I - K * obj.C)' + K * R_cov * K';
                
                % Set these as the new prior for the next horizon step.
                x_prop = x_upd;
                P_prop = P_upd;
            end
            
            % After the loop, x_prop and P_prop represent the predicted state and covariance at time k.
            % The final innovation and its covariance (from the last measurement update) are:
            % innovation (from the final loop iteration) and S.
            % Compute the NIS:
            obj.currentInnovation = innovation;
            obj.currentNIS = innovation' / S * innovation;
            obj.currentP =P_prop;
            
        end

        
    end

end